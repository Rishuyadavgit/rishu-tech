import React from 'react';
import { useParams } from 'react-router-dom';
import { Star, ShoppingCart, Heart } from 'lucide-react';
import { useCartStore } from '../store/cart';

export function ProductDetail() {
  const { id } = useParams();
  const addToCart = useCartStore((state) => state.addItem);
  
  // Find product by ID (in a real app, this would be an API call)
  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-gray-900">Product not found</h2>
      </div>
    );
  }

  return (
    <div className="grid md:grid-cols-2 gap-12">
      {/* Product Image */}
      <div className="aspect-square rounded-xl overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Product Info */}
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {product.name}
          </h1>
          <div className="flex items-center gap-2">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="h-5 w-5"
                  fill={i < product.rating ? 'currentColor' : 'none'}
                />
              ))}
            </div>
            <span className="text-gray-600">({product.reviews} reviews)</span>
          </div>
        </div>

        <p className="text-3xl font-bold text-gray-900">
          ${product.price.toFixed(2)}
        </p>

        <p className="text-gray-600">{product.description}</p>

        <div className="space-y-4">
          <button
            onClick={() => addToCart(product)}
            className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition"
          >
            <ShoppingCart className="h-5 w-5" />
            Add to Cart
          </button>
          <button className="w-full flex items-center justify-center gap-2 bg-gray-100 text-gray-900 px-6 py-3 rounded-lg font-semibold hover:bg-gray-200 transition">
            <Heart className="h-5 w-5" />
            Add to Wishlist
          </button>
        </div>

        <div className="border-t pt-6">
          <h3 className="font-semibold text-gray-900 mb-4">Product Details</h3>
          <ul className="space-y-2 text-gray-600">
            {product.details.map((detail, index) => (
              <li key={index}>{detail}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

const products = [
  {
    id: '1',
    name: 'Wireless Headphones',
    price: 199.99,
    description: 'Premium wireless headphones with active noise cancellation, delivering crystal-clear sound quality and exceptional comfort for extended listening sessions.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
    category: 'electronics',
    rating: 4,
    reviews: 128,
    details: [
      'Active Noise Cancellation',
      '30-hour battery life',
      'Bluetooth 5.0',
      'Built-in microphone',
      'Foldable design',
    ],
  },
  // Add more products as needed
];