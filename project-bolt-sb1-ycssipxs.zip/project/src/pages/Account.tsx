import React from 'react';
import { useLocation } from 'react-router-dom';
import {
  User,
  Package,
  Heart,
  CreditCard,
  MapPin,
  Settings,
  LogOut,
} from 'lucide-react';

export function Account() {
  const location = useLocation();
  const showOrderSuccess = location.state?.orderPlaced;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {showOrderSuccess && (
        <div className="bg-green-50 text-green-800 px-6 py-4 rounded-lg mb-8">
          <p className="font-medium">Order placed successfully!</p>
          <p className="text-sm">
            Thank you for your purchase. You'll receive a confirmation email
            shortly.
          </p>
        </div>
      )}

      <div className="flex items-center gap-6">
        <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center">
          <User className="h-10 w-10 text-gray-500" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">John Doe</h1>
          <p className="text-gray-600">john.doe@example.com</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-4">
          <h2 className="font-semibold text-gray-900">Account</h2>
          <nav className="space-y-2">
            {accountLinks.map((link) => (
              <button
                key={link.name}
                className="w-full flex items-center gap-3 px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition"
              >
                <link.icon className="h-5 w-5" />
                {link.name}
              </button>
            ))}
          </nav>
        </div>

        <div className="md:col-span-2 space-y-6">
          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Recent Orders
            </h2>
            {orders.length > 0 ? (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    className="flex items-center gap-4 p-4 border rounded-lg"
                  >
                    <div className="w-16 h-16 rounded-md overflow-hidden flex-shrink-0">
                      <img
                        src={order.image}
                        alt={order.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-grow">
                      <h3 className="font-medium text-gray-900">{order.name}</h3>
                      <p className="text-sm text-gray-600">
                        Order #{order.id} • {order.date}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-gray-900">
                        {formatPrice(order.total)}
                      </p>
                      <p
                        className={`text-sm ${
                          order.status === 'Delivered'
                            ? 'text-green-600'
                            : 'text-blue-600'
                        }`}
                      >
                        {order.status}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-600">No orders yet</p>
            )}
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Saved Addresses
            </h2>
            <div className="grid grid-cols-2 gap-4">
              {addresses.map((address) => (
                <div
                  key={address.id}
                  className="p-4 border rounded-lg relative group"
                >
                  <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition">
                    <button className="text-gray-400 hover:text-gray-600">
                      <Settings className="h-4 w-4" />
                    </button>
                  </div>
                  <p className="font-medium text-gray-900 mb-1">
                    {address.name}
                  </p>
                  <p className="text-sm text-gray-600">{address.street}</p>
                  <p className="text-sm text-gray-600">
                    {address.city}, {address.state} {address.zip}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const accountLinks = [
  { name: 'Profile', icon: User },
  { name: 'Orders', icon: Package },
  { name: 'Wishlist', icon: Heart },
  { name: 'Payment Methods', icon: CreditCard },
  { name: 'Addresses', icon: MapPin },
  { name: 'Settings', icon: Settings },
  { name: 'Log Out', icon: LogOut },
];

const orders = [
  {
    id: '1234',
    name: 'Wireless Headphones',
    date: 'March 14, 2024',
    total: 199.99,
    status: 'Delivered',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e',
  },
  {
    id: '1235',
    name: 'Smart Watch',
    date: 'March 10, 2024',
    total: 299.99,
    status: 'In Transit',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30',
  },
];

const addresses = [
  {
    id: '1',
    name: 'Home',
    street: '123 Main St',
    city: 'New York',
    state: 'NY',
    zip: '10001',
  },
  {
    id: '2',
    name: 'Work',
    street: '456 Business Ave',
    city: 'New York',
    state: 'NY',
    zip: '10002',
  },
];

function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(price);
}